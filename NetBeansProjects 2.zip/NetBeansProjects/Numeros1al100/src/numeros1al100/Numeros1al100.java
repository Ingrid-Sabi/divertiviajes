
package numeros1al100;


public class Numeros1al100 {


    public static void main(String[] args) {
        
        int x;
        System.out.println("\nCon ciclo para");
        
        for (x=1; x<=100; x++)  {
            System.out.println(x + "\t");
            if (x%10==0) System.out.println();
            
        }    
        System.out.println("\n Con ciclo while");  
        x=1;
         while (x<=100){
                System.out.println(x);
                x++;
        }     
             
        
    }
    
}
