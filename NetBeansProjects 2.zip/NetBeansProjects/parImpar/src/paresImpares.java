import java.util.Scanner;

public class paresImpares {


    public static void main(String[] args) {
    Scanner scanner=new Scanner(System.in);
    
        System.out.println("digita el numero ");
        int numero= scanner.nextInt();
        
        if (numero % 2 == 0){
            System.out.println("es par");
        }
        else {
            System.out.println("no es par ");
        }
    }
    
}
