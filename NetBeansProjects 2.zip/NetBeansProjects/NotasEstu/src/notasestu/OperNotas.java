
package notasestu;


public class OperNotas {
    

    String nombreMEstu ;
    public void mostrarMatrizNotas(String[] estudiantes, double[][] notas) {
        System.out.println("Matriz de Notas:");
        for (int i = 0; i < estudiantes.length; i++) {
            System.out.print(estudiantes[i] + ": ");
            for (int j = 0; j < notas[i].length; j++) {
                System.out.print(notas[i][j] + " ");
            }
            System.out.println();
        }
    }

  
    public void estudianteConMayorPromedio(String[] estudiantes, double[][] notas) {
        
        double mayorPromedio = 0;

        for (int i = 0; i < estudiantes.length; i++) {
          
            double sumaN = 0;
            for (int j = 0; j < notas[i].length; j++) {
                sumaN += notas[i][j];
            }
            double promedio = sumaN / notas[i].length;

        
            if (promedio > mayorPromedio) {
                mayorPromedio = promedio;
                nombreMEstu = estudiantes[i];
            }
        }

 
        System.out.println("El estudiante con la mayor nota definitiva es " + nombreMEstu + " con un promedio de " + mayorPromedio);
    }
}