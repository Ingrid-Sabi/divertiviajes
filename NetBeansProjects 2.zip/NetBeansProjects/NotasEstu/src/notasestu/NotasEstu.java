
package notasestu;


import java.util.Scanner;

public class NotasEstu {
    public static void main(String[] args) {
    
        Scanner sc = new Scanner(System.in);

   
        System.out.println("Ingrese # de estudiantes:");
        int cantidadEstudiantes = sc.nextInt();
        sc.nextLine();  

     
        String[] estudiantes = new String[cantidadEstudiantes];

   
        double[][] notas = new double[cantidadEstudiantes][];

 
        for (int i = 0; i < cantidadEstudiantes; i++) {
            System.out.println("Ingrese el nombre del estudiante #" + (i + 1) + ":");
            estudiantes[i] = sc.nextLine();

             

        
            notas[i] = new double[3];

            System.out.println("Ingrese las notas de " + estudiantes[i] + ":");
            for (int j = 0; j < 3; j++) {
                System.out.println("Nota de la materia #" + (j + 1) + ":");
                notas[i][j] = sc.nextDouble();
            }
            sc.nextLine();  
        }


        OperNotas operNotas = new OperNotas();
        operNotas.mostrarMatrizNotas(estudiantes, notas);
        operNotas.estudianteConMayorPromedio(estudiantes, notas);
        
    }
}
    
    




    
