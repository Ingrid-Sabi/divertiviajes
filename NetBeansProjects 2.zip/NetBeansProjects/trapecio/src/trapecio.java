
public class trapecio {
    
    
}
