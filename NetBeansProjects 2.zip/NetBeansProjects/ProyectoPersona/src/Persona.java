
public class Persona {
   private String nombre;
   private int edad;
   private String cedula;
   
   public Persona(String nombre, String cedula, int edad)
   {
       this.nombre=nombre;
       this.cedula= cedula;
       this.edad=edad;
   }        

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public String getCedula() {
        return cedula;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }


    
}

