
public class Empleado extends Persona {
    
    private  String cargo;
    private  float salario;
    


    public Empleado( String nombre, String cedula, int edad,String cargo,float salario) 
    {
        
    
        super(nombre, cedula, edad);
        this.cargo = cargo;
        this.salario = salario;
    }

    public void mostraDatos()
    {
        
        System.out.println("Nombre: "+getNombre());
        System.out.println("Edad: "+getEdad());
        System.out.println("Cedula: "+getCedula());
        System.out.println("Cargo: "+cargo);
        System.out.println("salario: "+salario);
       
    }
}