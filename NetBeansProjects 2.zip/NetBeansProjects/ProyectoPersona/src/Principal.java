
public class Principal {

    public static void main(String[] args)
    {
       
       Empleado ep=new Empleado ("juan","10002",18,"gerente",5000);
       
       ep.mostraDatos();
       ep.setEdad(19);
       ep.mostraDatos();
    }
    
}
