
public class Calculos {
    
    protected double resultado;
    
    public void areac (double lado){
        
        resultado = lado * lado;
    }
    public void areat (double base, double altura){
        
        resultado = base * altura/2;
        
    }
    public void arear (double baser, double alturar){
        
        resultado = baser * alturar;
    }
    
}
