import java.util.Scanner;
public class Operaciones {
    Scanner sc=new Scanner(System.in);
    int n1,n2,suma,resta,multiplicacion,division;
    
    public void EntradaDatos()
    { 
        System.out.println("digite el numero uno ");
        n1=sc.nextInt();
        System.out.println("digite el numero 2 ");
        n2=sc.nextInt();
        
    }  
    
    public void sumar ()
    { 
        suma=n1+n2;
        System.out.println("la summa es "+ suma );
    }        
    
    public void restar ()
    {
        resta=n1-n2;
        System.out.println("la resta es "+resta);
    }     
    
    public void multiplicar()
    {
       multiplicacion=n1*n2;
        System.out.println("la multiplicacion es "+ multiplicacion);
        
    }   
    
    public void dividir()
    {
       if ( n2 != 0)
       division= n1/n2;
        System.out.println("la division es "+division);
          
    
    }        
}
