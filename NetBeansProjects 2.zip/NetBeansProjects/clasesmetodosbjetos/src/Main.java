
public class Main {
    public static void main (String[]args)
    {
       Operaciones op=new Operaciones ();
       op.EntradaDatos();
       op.sumar();
       op.restar();
       op.dividir();
       op.multiplicar();
    }        
    
}
