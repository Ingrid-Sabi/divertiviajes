import java.util.Scanner;
public class NewMain {

    public static void main(String[] args) {
      Scanner scanner=new Scanner(System.in);
      
        System.out.println("ingrese su edad");
        int edad = scanner.nextInt();
        
        if (edad >= 18){
            System.out.println("eres mayor");
            
        } else {
            System.out.println("eres menor");}
    }
    //scanner.close();
    
}
