String total = null;
        if (rbm.isSelected())
            
            if (cbc1.isSelected())
                total="ERES MUJER Y HAZ SELECCIONADO AL CANDIDATO 1";
            else
                if(cbc2.isSelected())
                    total="ERES MUJER Y HAZ SELECCIONADO AL CANDIDATO 2";
                else
                    if(cbc3.isSelected())
                        total="ERES MUJER Y HAZ SELECCIONADO AL CANDIDATO 3";
         
          if (cbc1.isSelected() && cbc2.isSelected())
                total="ERES MUJER Y HAZ SELECCIONADO AL CANDIDATO 1 Y CANDIDATO 2"; 
            
            
          else if(cbc1.isSelected() && cbc3.isSelected())
              total="ERES MUJER Y HAZ SELECCIONADO AL CANDIDATO 1 Y CANDIDATO 3";
                
          else if (cbc2.isSelected() && cbc3.isSelected())
              total="ERES MUJER Y HAZ SELECCIONADO AL CANDIDATO 2 Y CANDIDATO 3";
          if (cbc1.isSelected() && cbc2.isSelected() && cbc3.isSelected())
              total="ERES MUJER Y HAZ SELECCIONADO A LOS TRES CANDIDATOS";
          
        
        if (rbh.isSelected())
            
            if (cbc1.isSelected())
                total="ERES HOMBRE Y HAZ SELECCIONADO AL CANDIDATO 1";
            else
                if(cbc2.isSelected())
                    total="ERES HOMBRE Y HAZ SELECCIONADO AL CANDIDATO 2";
                else
                    if(cbc3.isSelected())
                        total="ERES HOMBRE Y HAZ SELECCIONADO AL CANDIDATO 3";
         
         if (cbc1.isSelected() && cbc2.isSelected())
            total="ERES HOMBRE Y HAZ SELECCIONADO AL CANDIDATO 1 Y CANDIDATO 2"; 
            
            
          else if(cbc1.isSelected() && cbc3.isSelected())
              total="ERES HOMBRE Y HAZ SELECCIONADO AL CANDIDATO 1 Y CANDIDATO 3";
                
          else if (cbc2.isSelected() && cbc3.isSelected())
            total="ERES HOMBRE Y HAZ SELECCIONADO AL CANDIDATO 2 Y CANDIDATO 3";
          if (cbc1.isSelected() && cbc2.isSelected() && cbc3.isSelected())
            total="ERES HOMBRE Y HAZ SELECCIONADO A LOS TRES CANDIDATOS";
          
          
        String pr=String.valueOf(total);
        mensajeresultado.setText(pr);