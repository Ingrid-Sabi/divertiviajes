
package ejercicio;

import java.util.Scanner;
        
public class Ejercicio {
   int edad,peso,horas;
   double estatura; String genero;
   
    
   public void cargarDatos()
   {
    
       Scanner sc=new Scanner(System.in);
       System.out.println("para participar en la competencia debes dar los siguientes datos para calcular si puedes participar");
       System.out.println("digita tu edad: ");
       edad = sc.nextInt();
       System.out.println("digita tu peso en kilogramos: ");
       peso = sc.nextInt();
       System.out.println(" digita las horas de entrenamiento previas a la competencia: ");
       horas = sc.nextInt();
       System.out.println("digita tu estatura actual en metros ");
       estatura = sc.nextDouble();
       System.out.println("digite su genero");
       genero= sc.next();
       
   }
   public void puedeOno()
   {
       if (edad >= 18){
           if (peso>=50){
               if (horas>=50){
                   if (estatura > 1.50){
                       System.out.println(" el competidor de genero "+genero+ " cumple con los requisitos");
                   }else {  
                       System.out.println(" el competidor de genero "+genero+ " no cumple con la estaura");}
               }else{
                   System.out.println(" el competidor de genero "+genero+ " no cumple con las horas ");}
           }else{
               System.out.println(" el competidor de genero " +genero+ " no cumple con el peso");}
       }else {
           System.out.println(" el competidor de genero "+genero+ " no cumple con la edad");}
                            
                          
    }                       
         
    public static void main(String[] args) {   
        
        Ejercicio competidor= new Ejercicio();
        competidor.cargarDatos();
        competidor.puedeOno();
        
        
        
    }
    
}
