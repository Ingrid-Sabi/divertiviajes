
package vectores;

import java.util.Scanner;
public class Vectores {
    public static void main(String[] args) {
       Scanner sc=new Scanner (System.in);
       int datob,n;
       float prom=0;
       
       Operaciones op=new Operaciones();
       
        System.out.println("digite el tamaño del vector ");
        n = sc.nextInt();
        int vector[]=op.CargarVector(n);
        op.Imprimirvector(n, vector);
        System.out.println("digite el dato a buscar ");
        datob=sc.nextInt();
        op.BuscarDato(datob, vector);
        prom=op.CalculoPromedio(vector);
        System.out.println("el promedio es :"+prom);
         
               
    }
    
}
