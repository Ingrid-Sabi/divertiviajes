
package vectores;

import java.util.Scanner;

public class Operaciones {
    Scanner sc= new Scanner(System.in);
    
    public int [] CargarVector(int n){
        int vector [] = new int [n];
        for (int i=0; i<n; i++) {
            System.out.println("digite un dato en :"+i);
            vector[i]=sc.nextInt();
            
        }
        return vector;
    }
    
    public void Imprimirvector (int n, int vector[]){
        for(int i=0;i<n; i++){
            System.out.println("vector["+i+"]="+vector[i]);
        } 
    }   
    
        



     
    public void BuscarDato (int datob, int vector[]){
        int pos=vector[0],sw=0;
        for (int i=0; i<vector.length; i++){
            if(vector[i]== datob){
                pos =i;
                sw = 1;
            }
        }
        if (sw==0)
            System.out.println("El dato"+datob+"no esta ");
        else
            System.out.println("el dato"+datob+"si esta ");
        
    } 
    public float CalculoPromedio (int vector[]){
        int suma=0, cont=0;
        float promedio;
        for (int i=0; i < vector.length; i=i+2){
            suma= suma +vector[i];
            cont = cont+1;
                    
        }
        promedio= suma/cont;
        return promedio;
    }
    
            
    
}
