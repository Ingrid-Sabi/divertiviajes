import java.util.Scanner;
public class diasSemana {

    
    public static void main(String[] args) {
    Scanner scanner=new Scanner(System.in);
    
    System.out.println(" digite un numero para saber el dia de la semana ");
    int dia = scanner.nextInt();
    
    switch (dia){
        case 1:
            System.out.println("lunes");
            break;
        case 2:
            System.out.println("martes");
            break;
        case 3:
            System.out.println("miercoles");
            break;
        case 4:
            System.out.println("jueves");
            break; 
        default:
            System.out.println("numero no valido perro");
    }        
    scanner.close();
    
    }
    
}
