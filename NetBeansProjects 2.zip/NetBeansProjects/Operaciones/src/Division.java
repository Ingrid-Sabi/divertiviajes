public class Division extends Operaciones {
    
    @Override
    
    public void Operacion ()
    {
        
        while( true){
            if (valor2!=0){
               resultado = valor1*valor2;
               break;
           }else {
                System.out.println("los valores deben ser diferentes a cero (0)");}
        }
    }        
    
}
