

public class Resta extends Operaciones {
    
    @Override
    
    public void Operacion ()
    {
        resultado = valor1-valor2;
    }        
    
}
