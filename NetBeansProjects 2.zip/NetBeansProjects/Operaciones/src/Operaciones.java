import java.util.Scanner;
public abstract class  Operaciones {
    protected int valor1, valor2, resultado;
    Scanner sc=new Scanner (System.in);
    
    public void CargarDatos()
    {
        System.out.println("digite valor uno: ");
        valor1=sc.nextInt();
        
        System.out.println("digite valor dos: ");
        valor2=sc.nextInt();
        
    }        
    public abstract void Operacion();
    
    public void MostrarDatos()
    {
        System.out.println(resultado);
        
    }        
          
}
