public class Multiplicacion extends Operaciones {
    
    @Override
    
    public void Operacion ()
    {
        resultado = valor1*valor2;
    }        
    
}
