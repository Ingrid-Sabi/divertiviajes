
public class Principal {

    public static void main(String[] args) 
    {
      Operaciones ops=new suma ();
      ops.CargarDatos();
      ops.Operacion();
      ops.MostrarDatos();
      
      Operaciones opr=new Resta();
      opr.CargarDatos();
      opr.Operacion();
      opr.MostrarDatos();
      
      Operaciones opm=new Multiplicacion();
      opm.CargarDatos();
      opm.Operacion();
      opm.MostrarDatos();
      
      Operaciones opd=new Division();
      opd.CargarDatos();
      opd.Operacion();
      opd.MostrarDatos();
      
    }
    
}
