
package notas;

import java.util.Scanner;
public class Notas {
    
    public static void main(String[] args) {
        Scanner sc=new Scanner (System.in);
        int n, posm,pierc;
        OperEstu ope=new OperEstu();
        System.out.println("digite el tamaño del grupo");
        n= sc.nextInt();
       
        String nombres[]=ope.CargarNombres(n);
        float notas[]=ope.CargarNotas(n);
        
        ope.MostarNombres(n, nombres);
        ope.MostarNotas(n, notas);
        
        posm = ope.NotaMayor(n, notas);
        
        System.out.println("el estudiante con nota mayor:" + nombres[posm]);
        System.out.println("");
        pierc =ope.PierdenCurso(n, notas);
        System.out.println("pierden el curso: "+pierc+" estudiante");
        
        
        
    
 
    }
    
}
