
package notas;
import java.util.Scanner;
public class OperEstu {
    Scanner sc=new Scanner(System.in);
    
    public float[] CargarNotas(int n){
       float notas[]=new float[n];
       for(int i=0; i<notas.length; i++){
           System.out.println("digite una nota en:"+i);
           notas[i]=sc.nextFloat();
       }
       return notas;
    }
    
    public String[] CargarNombres(int n){
         String nombres[]=new String[n];
         for (int i=0; i<nombres.length; i++){
             System.out.println("digite el nombre en: "+i);
             nombres[i]=sc.nextLine();
         }
         return nombres;
    }
    
    public void MostarNombres (int n,String nombre[]){
        System.out.println("el siguiente es el vector de nombre: ");
        for (int i=0; i<nombre.length; i++){
            System.out.println("nombres[ "+i+"]="+ nombre [i]);
            
        }
    }
    public void MostarNotas (int n, float notas[]){
        System.out.println("el siguiente es el vector de notas:");
        for (int i=0; i<notas.length; i++){
            System.out.println("notas["+i+"]="+notas[i]);
            
            
        }
    }
    public int NotaMayor(int n,float notas[]){
        float notamay= notas[0];
        int posmay = 0;
        for (int i=0; i<notas.length; i++){
            if(notas[i]>notamay){
                notamay=notas[i];
                posmay=i;
            }
        } 
        return posmay;
    }
    
    public int PierdenCurso(int n, float notas[]){
        int contpierd=0;
        for (int i=0; i<notas.length; i++){
            if (notas[i]<3)
                contpierd = contpierd + 1 ;
            
        }
        return contpierd;
         
    }
    
    
}
