import java.util.Scanner;
public class gananpierden {
    Scanner teclado=new Scanner(System.in);
    int estudiantes,contg=0,contp=0;
    double nota;
    
    public void gp()
    {
        System.out.println("Digite la cantidad de estudiantes");
        estudiantes=teclado.nextInt();
        for(int i=1; i<=estudiantes; i++)
        {
            System.out.println("Digite la nota definitiva");
            nota=teclado.nextDouble();
            if(nota>3)
                contg=contg+1;
            else
                contp=contp+1;
        }
        System.out.println("La cantidad de estudiantes que ganaron es: "+contg);
        System.out.println("La cantidad de estudiantes que Perdieron es: "+contp);
    }
    
}






