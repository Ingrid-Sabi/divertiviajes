public class Main {
    public static void main(String[] args)
    {
        gananpierden op=new gananpierden();
        op.gp();
        
        
    }
    
}
