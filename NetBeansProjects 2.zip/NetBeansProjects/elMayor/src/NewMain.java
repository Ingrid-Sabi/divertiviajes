import java.util.Scanner;
public class NewMain {
     int n1,n2,n3;
     public void CargarDatos()
     {
         do{Scanner sc=new Scanner(System.in);
            System.out.println("digite 3 numeros diferentes ");
            System.out.println("digite el numero 1");
            n1=sc.nextInt();
            System.out.println("digite el numero 2");
            n2= sc.nextInt();
            System.out.println("digite el numero 3");
            n3= sc.nextInt();
         }while(n1==n2 || n1==n3 || n2==n3);
    }     
         
     public void MostrarDatos()
     {
         System.out.println("el valor de la variable 1 es:"+n1);
         System.out.println("el valor de la variable 2 es:"+n2);
         System.out.println("el valor de la variable 3 es:"+n3);
     }
     public void Mayor()
     {     
          int may;
          may=n1;
          if (n2 > may)
             may=n2;
          if (n3 > may)
             may=n3;
          System.out.println("el numero mayor es :"+may);
          
     }
     public void menor()
     {
         int men;
         men=n1; 
         if (n2< men)
             men=n2;
         if (n3< men)
             men=n3;
         System.out.println("el numero menor es:"+men);
     }        
    
    
    
    
    public static void main(String[] args) {
        NewMain  maymen=new NewMain ();
        maymen.CargarDatos();
        maymen.MostrarDatos();
        maymen.Mayor();
        maymen.menor();
        
       
    }
    
    
}
