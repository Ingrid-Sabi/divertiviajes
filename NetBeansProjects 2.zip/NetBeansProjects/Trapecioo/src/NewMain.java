


import promedioymenor.Consola;

public class NewMain {

    public static void main(String[] args) {
        double baseMenor, baseMayor, altura, ladoIzquierdo, ladoDerecho, area, perimetro;
        
        // Imprimir mensaje inicial
        Consola.imprimir("Para calcular el Área y Perímetro ingrese las dimensiones del trapecio en CM");
        
        // Solicitar las medidas del trapecio
        Consola.imprimir("Ingrese la base menor del trapecio: ");
        baseMenor = Consola.leerReal();
        
        Consola.imprimir("Ingrese la base mayor del trapecio: ");
        baseMayor = Consola.leerReal();
        
        Consola.imprimir("Ingrese la altura del trapecio: ");
        altura = Consola.leerReal();
        
        Consola.imprimir("Ingrese el lado izquierdo del trapecio: ");
        ladoIzquierdo = Consola.leerReal();
        
        Consola.imprimir("Ingrese el lado derecho del trapecio: ");
        ladoDerecho = Consola.leerReal();
        
        // Calcular el área y el perímetro
        area = ((baseMenor + baseMayor) * altura) / 2;
        perimetro = baseMenor + baseMayor + ladoIzquierdo + ladoDerecho;
        
        // Imprimir los resultados
        Consola.imprimir("El Área del trapecio es: " + area + " CM² y su Perímetro es: " + perimetro + " CM.");
    }
}
