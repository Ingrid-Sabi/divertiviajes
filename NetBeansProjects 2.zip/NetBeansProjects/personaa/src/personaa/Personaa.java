
package personaa;

public class Personaa {

    private String nombre ;
    private int edad;
    private String getNombre;
    private String getEdad;
    
    
public Personaa (String nombre, int edad)   
{
    this.nombre=nombre;
    this.edad=edad;
}

public String getNombre()
{
    return nombre;
}        

public void setNombre(String nombre)
{
    this.nombre=nombre;
}

public int getEdad()
{
    return edad;
}        

public void setEdad (int edad)
{
    this.edad=edad;
}        
    
 
            
            
            
            
            
    public static void main(String[] args) {
       
        Personaa per=new Personaa("juan",35);
        System.out.println("nombre"+per.getNombre);
        System.out.println("edad"+per.getEdad);
        per.setEdad(25);
        System.out.println("la nueva edad es:"+per.getEdad());
    }   
        
    
}
