
package empresa;

public class Empresa {
    
    private static Empleado vecEmp[];
    
    private static int n;
    
    public static void main(String[] args) {
       ingresarEmpleado();
       nomina();
       
    }
    public static void ingresarEmpleado() {
       Consola.imprimir("digite la cantidad de empleados");
       n = Consola.leerEntero();
       //dimensionar el arreglo
       vecEmp = new Empleado[n];
       //ingesar daros de los empleados 
       for(int i=0; i<n; i++){
           //reservar memoria para un empleado
           vecEmp[i] = new Empleado();
           Consola.imprimir("\nEMPLEADO #"+ (i+1));
           Consola.imprimir("ingrese el nombre del empleado: ");
           vecEmp[i].setNom(Consola.leerTexto());
           Consola.imprimir("digite las horas trabajadas ");
           vecEmp[i].setNht(Consola.leerEntero());
           Consola.imprimir("costo de la hora: $ ");
           vecEmp[i].setCostoHora(Consola.leerReal());    

       }
       
       
    }
    
    public static void nomina() {
        
       Consola.imprimirLn(\nNOMINA DE LA EMPRESA);
       Consola.imprimirLn("NOMBRE\t\t\ SALARIO");
       
       for(int i=0; i<n; i++)
           Consola.imprimirLn(vecEmp[i].getNom()+"\");
       
    }
    
    public static void empleadosMayorSueldo() {
       
    }
    
    public static double salarioProm() {
        double sueldoProm=21;
        
        return sueldoProm;
       
    }
    
    public static double porcEM40() {
        double porc=21;
        
        return porc;
       
    }
}    