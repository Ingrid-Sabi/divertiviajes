
package empresa;


public class Empleado {
    private String nom;
    private int nht;
    private double valorHora;
   // constructor vacio 
    public Empleado() {
    }
    //contructor sobre crgado

    public Empleado(String nom, int nht, double valorHora) {
        this.nom = nom;
        this.nht = nht;
        this.valorHora = valorHora;
    }
    //metodos de carga 

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setNht(int nht) {
        this.nht = nht;
    }

    public void setValorHora(double valorHora) {
        this.valorHora = valorHora;
    }
    //metodos de acceso

    public String getNom() {
        return nom;
    }

    public int getNht() {
        return nht;
    }

    public double getValorHora() {
        return valorHora;
    }
    // metodod analizador 
    public double calcularSalario()
    {
        double  salario;
        salario = nht* valorHora;
        return salario;
                
    }
}
