import java.util.Scanner;
public class bonificacion {


    public static void main(String[] args) {
      Scanner scanner=new Scanner(System.in);
      float valorPagar,valorTotal,calcular,descuento=0; String tipoBono;

        System.out.println("ingrese el tipo de bono");
        tipoBono= scanner.next();
        System.out.println("ingrese el valor a pagar");
        valorPagar= scanner.nextFloat();
        
        switch (tipoBono){
            
            case "orogold":
                descuento = 25;
                break;
            case "plata": 
                descuento = 20;
                break;
            case "platino":
                descuento = 15;
                break;
                
        }        
        scanner.close();
        
        calcular= valorPagar*descuento/100;
        valorTotal= valorPagar - calcular;
        System.out.println("el descuento es"+ calcular );
        System.out.println("el valor total es "+ valorTotal );
        
    }
    
}
