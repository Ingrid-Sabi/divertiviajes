
public class Operaciones {
    protected double resultado;
    
    public void suma(double n1,double n2){
         resultado =n1 + n2;
         }
    
    public void resta(double n1,double n2){
         resultado =n1 - n2;
         }
    public void mult(double n1,double n2){
         resultado =n1 * n2;
         }
    public void div (double n1,double n2){
         resultado =n1 * n2;
         }
}
