
package ejercicio4;


public class Ejercicio4 {


    public static void main(String[] args) {
        // creacion de dos empleados
        Empleado e1 = new Empleado();
        Empleado e2 = new Empleado("james Rodrigues",45,345667);
        //estado de los objetos 
        System.out.print("primer empleado:");
        System.out.println("nombre: "+ e1.getNom());
        System.out.println("numero e horas trabajadas:"+ e1.getNht());
        System.out.println("valor de la hora $:"+e1.getValorHora());
        
        System.out.println("segundo empleado");
        System.out.println("nombre: "+ e2.getNom());
        System.out.println("numero e horas trabajadas: "+ e2.getNht());
        System.out.println("valor de la hora $:"+e2.getValorHora());
        System.out.println("salario primer empleado: $"+e1.calcularSalario());
        System.out.println("salario segundo empleado: $"+e2.calcularSalario());
 
    }
    
}
