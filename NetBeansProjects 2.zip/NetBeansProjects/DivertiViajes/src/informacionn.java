
import javax.swing.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Informacion extends javax.swing.JFrame {

    // Clase interna para guardar registros
    class Registro {
        String nombre;
        int cantidad;
        String plan;
        double total;

        public Registro(String nombre, int cantidad, String plan, double total) {
            this.nombre = nombre;
            this.cantidad = cantidad;
            this.plan = plan;
            this.total = total;
        }
    }

    // Lista para guardar todos los registros
    private ArrayList<Registro> registros = new ArrayList<>();

    public Informacion() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        // Crear componentes
        jLabel1 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtCantidad = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        rbFamiliar = new javax.swing.JRadioButton();
        rbParejas = new javax.swing.JRadioButton();
        btnGuardar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtFactura = new javax.swing.JTextArea();
        btnRegresar = new javax.swing.JButton();
        buttonGroup1 = new javax.swing.ButtonGroup();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Registro de Viajes - DIVERTI VIAJES");
        setSize(500, 450);
        setLocationRelativeTo(null);

        jLabel1.setText("Nombre del cliente:");

        jLabel2.setText("Cantidad de personas:");

        jLabel3.setText("Plan de descuento:");

        buttonGroup1.add(rbFamiliar);
        rbFamiliar.setText("Familiar");

        buttonGroup1.add(rbParejas);
        rbParejas.setText("Parejas");

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        txtFactura.setEditable(false);
        txtFactura.setColumns(20);
        txtFactura.setRows(10);
        jScrollPane1.setViewportView(txtFactura);

        btnRegresar.setText("Página Principal");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        // Layout (usamos GroupLayout para organizar)
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);

        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(25, 25, 25)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel1)
                        .addComponent(jLabel2)
                        .addComponent(jLabel3))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(txtNombre)
                        .addComponent(txtCantidad)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(rbFamiliar)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(rbParejas))
                        .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(50, Short.MAX_VALUE))
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane1)
                    .addContainerGap())
                .addGroup(layout.createSequentialGroup()
                    .addGap(180, 180, 180)
                    .addComponent(btnRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(180, Short.MAX_VALUE))
        );

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(25, 25, 25)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(15, 15, 15)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(15, 15, 15)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(rbFamiliar)
                        .addComponent(rbParejas))
                    .addGap(20, 20, 20)
                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(20, 20, 20)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(15, 15, 15)
                    .addComponent(btnRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {
        String nombre = txtNombre.getText().trim();
        String cantidadStr = txtCantidad.getText().trim();
        int cantidad;

        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa el nombre del cliente.");
            return;
        }

        try {
            cantidad = Integer.parseInt(cantidadStr);
            if (cantidad <= 0) {
                JOptionPane.showMessageDialog(this, "Ingrese una cantidad válida (mayor que 0).");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa un número válido para la cantidad.");
            return;
        }

        String plan = "";
        if (rbFamiliar.isSelected()) {
            plan = "Familiar";
        } else if (rbParejas.isSelected()) {
            plan = "Parejas";
        } else {
            JOptionPane.showMessageDialog(this, "Por favor selecciona un plan de descuento.");
            return;
        }

        double precioPorPersona = 500.0;
        double descuento = 0.0;

        if (plan.equals("Familiar") && cantidad >= 3) {
            descuento = 0.20;
        } else if (plan.equals("Parejas") && cantidad == 2) {
            descuento = 0.15;
        } else {
            descuento = 0.0;
        }

        double costoTotal = precioPorPersona * cantidad;
        double descuentoMonto = costoTotal * descuento;
        double totalConDescuento = costoTotal - descuentoMonto;

        LocalDate fecha = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String fechaFormateada = fecha.format(formatter);

        String factura = "";
        factura += "****** DIVERTI VIAJES ******\n";
        factura += "Fecha: " + fechaFormateada + "\n";
        factura += "Cliente: " + nombre + "\n";
        factura += "Cantidad de personas: " + cantidad + "\n";
        factura += "Plan de descuento: " + plan + "\n";
        factura += "Costo por persona: $" + precioPorPersona + "\n";
        factura += "Costo total sin descuento: $" + costoTotal + "\n";
        factura += "Descuento aplicado: " + (int)(descuento * 100) + "% ($" + descuentoMonto + ")\n";
        factura += "TOTAL A PAGAR: $" + totalConDescuento + "\n";
        factura += "****************************\n";

        txtFactura.setText(factura);

        guardarRegistro(nombre, cantidad, plan, totalConDescuento);
    }

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {
        this.setVisible(false);
        DivertiViajes principal = new DivertiViajes();
        principal.setVisible(true);
        // this.dispose(); // opcional para cerrar esta ventana
    }

    private void guardarRegistro(String nombre, int cantidad, String plan, double total) {
        registros.add(new Registro(nombre, cantidad, plan, total));
        // Aquí puedes agregar código para guardar en archivo o base de datos si quieres luego
    }

    // Variables declaration
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rbFamiliar;
    private javax.swing.JRadioButton rbParejas;
    private javax.swing.JTextArea txtFactura;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration

}

    public informacionn() {
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(informacionn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(informacionn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(informacionn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(informacionn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new informacionn().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
