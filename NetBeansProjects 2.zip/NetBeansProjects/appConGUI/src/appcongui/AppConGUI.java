
package appcongui;

public class AppConGUI {
    public static int mat [][];
            
            
    public static void main(String[] args) {
         FramePpal fp= new FramePpal();
         fp.setVisible(true);
    }
    
}
