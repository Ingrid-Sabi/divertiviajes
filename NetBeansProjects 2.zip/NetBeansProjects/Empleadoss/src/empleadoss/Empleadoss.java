package empleadoss;
import java.util.Scanner;
public abstract class  Empleadoss {
    protected int salario,vh,ht; String nombre;
   
    Scanner sc=new Scanner (System.in);
    
    public void CargarDatos()
    {
        System.out.println("digite el valor de la hora: ");
        vh=sc.nextInt();
        
        System.out.println(" digite las horas trabajadas");
        ht=sc.nextInt();
        
        System.out.println("digite el nombre del trabajador: ");
        nombre=sc.next();
        
    }   
    public abstract void CalcularSalario();
    
    public void MostrarSalario()
    {
        System.out.println( " el salario del empleado"+nombre+"es:"+ salario);
        
    }        
      

}
