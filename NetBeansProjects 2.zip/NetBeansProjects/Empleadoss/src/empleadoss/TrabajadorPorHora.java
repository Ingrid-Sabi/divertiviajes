public class TrabajadorPorHora extends Empleadoss{
    
     @Override
    
    public void CalcularSalario ()
    {
       salario = vh*ht;
    }
}