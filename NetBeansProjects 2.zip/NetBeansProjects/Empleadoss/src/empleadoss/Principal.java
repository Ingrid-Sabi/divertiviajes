
package empleadoss;


public class Principal {

    
    public static void main(String[] args) {
         
    
        TrabajadorPorHora op=new TrabajadorPorHora("juan",);
        op.CargarDatos();
        op.CalcularSalario();
        op.MostrarSalario();
    }
    
    
}
