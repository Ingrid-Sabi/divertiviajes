
public class Alumno extends Persona {
    
    private int CodAlumno;
    private float NotaDef;
    
    public Alumno (String nombre, String apellido, int edad,int CodAlumno,float NotaDef)
    {
        super (nombre,apellido,edad);
        
        this.CodAlumno= CodAlumno;
        this.NotaDef= NotaDef;
    }        
    public void mostrardatos()
    {
        System.out.println("Nombre: "+getNombre());
        System.out.println("Apellido: "+getApellido());
        System.out.println("EDad: "+getEdad());
        System.out.println("El codigo es: "+CodAlumno);
        System.out.println("El nota definitiova es: "+NotaDef);
    }        
}
