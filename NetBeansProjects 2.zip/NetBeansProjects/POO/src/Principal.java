
public class Principal {
  
   public static void main (String[]args)
   {
      Alumno alu=new Alumno ("carlos","costa",45,10002,4.5f);
      Alumno alu2=new Alumno ("maria","castaño",34,10004,3.5f); 
   
      alu.mostrardatos();
      System.out.println("");
      alu2.mostrardatos();
      
     
      
    }
}  
